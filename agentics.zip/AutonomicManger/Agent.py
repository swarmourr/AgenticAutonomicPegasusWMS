from llama_index.core.agent.workflow import FunctionAgent, ReActAgent
from typing import Dict, Any, List, Optional
import yaml
import json
import re
import logging
from datetime import datetime
from llama_index.llms.together import TogetherLLM
from Tools.fullanalyse import *


# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("MAPE-K")

async def convert_yaml_python_workflow(workflow_descriptor_yaml: str) -> str:
    """
    Converts a YAML workflow descriptor to a Python workflow generator script.
    
    Args:
        workflow_descriptor_yaml: YAML string describing the workflow
        
    Returns:
        Python script string that generates the workflow
    """
    try:
        # Parse the YAML and convert to Python code
        # Placeholder for the actual implementation
        workflow_generator_python = "# Generated workflow code will be here"
        logger.info("Successfully converted YAML to Python workflow")
        return workflow_generator_python
    except Exception as e:
        logger.error(f"Error converting YAML to Python: {str(e)}")
        return f"# Error in conversion: {str(e)}"

async def log_analyser(logs: Dict[str, Any], workflow_descriptor_python: str) -> Dict[str, Any]:
    """
    Analyzes logs from failed workflow execution to identify issues.
    This function is triggered by workflow failure events.
    
    Args:
        logs: Dictionary containing workflow execution logs
        workflow_descriptor_python: The Python script that generated the workflow
        
    Returns:
        Dictionary with error analysis and suggested solutions
    """
    workflow_manager = PegasusWorkflowManager(
                            workflow_dir=iwd,
                            workflow_id=workflow_id,
                            api_url="https://api.together.xyz/v1/chat/completions",
                            api_key="9330fcf33a0d19c088c90a6799e1208f30c405627bc12cf27c4d4eaba36dcb96"
                        )
    workflow_manager.process_workflow()

async def plan_solution(workflow_generator_python: str) -> Dict[str, Any]:
    """
    Creates a plan to fix the workflow based on the analysis.
    
    Args:
        workflow_generator_python: The Python script that generated the workflow
        
    Returns:
        Dictionary containing the plan details
    """
    try:
        # Generate a plan to fix the workflow
        # Placeholder for the actual implementation
        plan = {
            "action": "update_resources",
            "target_components": ["task_id_123"],
            "changes": [
                {"type": "resource_update", "resource": "memory", "value": "4GB"},
                {"type": "resource_update", "resource": "cpu", "value": 2}
            ],
            "corrected_code": workflow_generator_python.replace("memory=2GB", "memory=4GB"),
            "expected_outcome": "Workflow should complete without memory errors"
        }
        logger.info(f"Solution plan created: {plan['action']}")
        return plan
    except Exception as e:
        logger.error(f"Error creating solution plan: {str(e)}")
        return {"error": str(e), "action": "none"}

async def execute_solution(corrected_workflow_generator_python: str) -> Dict[str, Any]:
    """
    Executes the corrected workflow generator script and submits the workflow.
    
    Args:
        corrected_workflow_generator_python: The corrected Python script
        
    Returns:
        Dictionary with execution status and results
    """
    try:
        # Execute the solution
        # Placeholder for the actual implementation
        result = {
            "workflow_id": "wf_fix_" + str(hash(corrected_workflow_generator_python) % 10000),
            "state": "Submitted",
            "submission_time": datetime.now().isoformat(),
            "workflow_script": corrected_workflow_generator_python
        }
        logger.info(f"Solution executed, workflow submitted: {result['workflow_id']}")
        return result
    except Exception as e:
        logger.error(f"Error executing solution: {str(e)}")
        return {"error": str(e), "state": "Failed"}

# Improved system prompt with focus on event-triggered monitoring
mape_k_system_prompt = """
You are a MAPE-K (Monitor, Analyze, Plan, Execute, Knowledge) agent specialized in managing Pegasus scientific workflows.

YOUR RESPONSIBILITIES:
1. ANALYZE: When triggered, identify the root causes of workflow failures by examining log patterns
2. PLAN: Develop a solution strategy based on the analysis
3. EXECUTE: Apply fixes and resubmit workflows
4. KNOWLEDGE: Build understanding of common workflow issues for future reference

EVENT-TRIGGERED APPROACH:
- You are activated when a workflow failure event occurs
- Each event contains workflow logs, error messages, and the workflow descriptor
- You do not actively poll for issues; instead, you respond to notification events
- The monitoring phase is handled by external sensors that feed data to you

ANALYSIS APPROACH:
- Distinguish between user implementation errors and system errors
- For user errors: Identify code issues, suggest corrections, and generate fixes
- For system errors: Explain the limitations encountered and suggest resource adjustments
- Prioritize solutions based on workflow requirements and available resources

SOLUTION PLANNING:
- Generate specific, actionable plans with concrete steps
- Update resource allocations when necessary
- Correct workflow code when implementation issues are found
- Provide clear explanations for each proposed change

EXECUTION GUIDELINES:
- Submit corrected workflows through the PegasusManager agent
- Monitor execution status via event notifications
- Document all changes for user reference
- Maintain execution history for knowledge building

Remember to analyze thoroughly before proposing solutions, and always verify resource availability before execution.
"""

llm = TogetherLLM(
    model="mistralai/Mixtral-8x7B-Instruct-v0.1", api_key="your_api_key"
)

# Create the MAPE-K agent
mape_k_agent = FunctionAgent(
    name="mape_k",
    description="Event-triggered agent for analyzing and fixing failed Pegasus workflows using the MAPE-K framework",
    system_prompt=mape_k_system_prompt,
    llm=llm,
    tools=[
        convert_yaml_python_workflow,
        log_analyser,
        plan_solution,
        execute_solution
    ],
    can_handoff_to=["PegasusManager"],
    verbose=True
)